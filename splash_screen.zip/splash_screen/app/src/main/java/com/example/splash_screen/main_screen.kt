
package com.example.splash_screen



import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class  main_screen : AppCompatActivity() {
    private  val ArrayInputs = IntArray(13)
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_screen)
//declarations
        val mon1 = findViewById<EditText>(R.id.mon1)
        val mon2 = findViewById<EditText>(R.id.mon2)
        val mon3 = findViewById<EditText>(R.id.mon3)
        val tue1 = findViewById<EditText>(R.id.tue1)
        val tue2 = findViewById<EditText>(R.id.tue2)
        val tue3 = findViewById<EditText>(R.id.tue3)
        val wen1 = findViewById<EditText>(R.id.wen1)
        val wen2 = findViewById<EditText>(R.id.wen2)
        val wen3 = findViewById<EditText>(R.id.wen3)
        val thur1 = findViewById<EditText>(R.id.thur1)
        val thur2 = findViewById<EditText>(R.id.thur2)
        val thur3 = findViewById<EditText>(R.id.thur3)
        val fri1 = findViewById<EditText>(R.id.fri1)
        val fri2 = findViewById<EditText>(R.id.fri2)
        val fri3 = findViewById<EditText>(R.id.fri3)
        val sat1 = findViewById<EditText>(R.id.sat1)
        val sat2 = findViewById<EditText>(R.id.sat2)
        val sat3 = findViewById<EditText>(R.id.sat3)
        val sun1 = findViewById<EditText>(R.id.sun1)
        val sun2 = findViewById<EditText>(R.id.sun2)
        val sun3 = findViewById<EditText>(R.id.sun3)

//declaration of the array that holds the data
        //if the button back is clicked
        findViewById<Button>(R.id.back).setOnClickListener {
            ArrayInputs[0] = mon1.text.toString().toInt()
            ArrayInputs[1] = mon2.text.toString().toInt()
            ArrayInputs[2] = mon3.text.toString().toInt()
            ArrayInputs[3] = tue1.text.toString().toInt()
            ArrayInputs[4] = tue2.text.toString().toInt()
            ArrayInputs[5] = tue3.text.toString().toInt()
            ArrayInputs[6] = wen1.text.toString().toInt()
            ArrayInputs[7] = wen2.text.toString().toInt()
            ArrayInputs[8] = wen3.text.toString().toInt()
            ArrayInputs[9] = thur1.text.toString().toInt()
            ArrayInputs[10] = thur2.text.toString().toInt()
            ArrayInputs[11] = thur3.text.toString().toInt()
            ArrayInputs[12] = fri1.text.toString().toInt()
            ArrayInputs[13] = fri2.text.toString().toInt()
            ArrayInputs[14] = fri3.text.toString().toInt()
            ArrayInputs[15] = sat1.text.toString().toInt()
            ArrayInputs[16] = sat2.text.toString().toInt()
            ArrayInputs[17] = sat3.text.toString().toInt()
            ArrayInputs[18] = sun1.text.toString().toInt()
            ArrayInputs[19] = sun2.text.toString().toInt()
            ArrayInputs[20] = sun3.text.toString().toInt()



            Toast.makeText(this,"Data saved successfully!",Toast.LENGTH_SHORT).show()

        }
        //if the button clear is clicked then all info stored will be erased
        findViewById<Button>(R.id.finish).setOnClickListener {
            ArrayInputs.fill(0)
            mon1.text.clear()
            mon2.text.clear()
            mon3.text.clear()
            tue1.text.clear()
            tue2.text.clear()
            tue3.text.clear()
            wen1.text.clear()
            wen2.text.clear()
            wen3.text.clear()
            thur1.text.clear()
            thur2.text.clear()
            thur3.text.clear()
            fri1.text.clear()
            fri2.text.clear()
            fri3.text.clear()
            sat1.text.clear()
            sat2.text.clear()
            sat3.text.clear()
            sun1.text.clear()
            sun2.text.clear()
            sun3.text.clear()


            Toast.makeText(this,"Data cleared. you can re-enter data.",Toast.LENGTH_SHORT).show()
        }
        //this function sends the user to the next page when all info has been stored
        findViewById<Button>(R.id.display).setOnClickListener {
            val intent = Intent (this, Detailed_view_screen :: class.java).apply{
                putExtra("screenTime",ArrayInputs)
            }
            startActivity(intent)
        }
    }
}