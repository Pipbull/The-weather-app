


package com.example.splash_screen

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
//this script is supposed to display all info that was inputted on the second page
class Detailed_view_screen : AppCompatActivity() {
    @SuppressLint("MissingInflatedId", "SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detailed_view_screen)

       /* val ArrayInputs = intent.getIntArrayExtra("") ?: intArrayOf()
        val categories = intent.getStringArrayExtra("categories") ?: arrayOf()
        //screenTime
        val totalScreenTime = ArrayInputs.sum()
        val averageScreenTime = if (ArrayInputs.isNotEmpty()) totalScreenTime / ArrayInputs.size else 0

       val mon1 = findViewById<EditText>(R.id.mon1).text

        findViewById<TextView>(R.id.mon1_l3).text = "w"
            findViewById<TextView>(R.id.textView11).text = "Average Screen Time:   minutes"
*/

//if the user is satisfied he/she will click the finish button the the program will stop
        findViewById<Button>(R.id.finish).setOnClickListener{
            finish()
        }
    }
}